import boto3

def pass_to_handler():
    client = boto3.client('iam')
    AccID =boto3.client('iam').get_user()['User']['Arn'].split(':')[4]

    policy = """{
        "Version":"2012-10-17",
        "Statement":[
        {
            "Sid":"Stmt1529995781482",
            "Action":"*",
            "Effect":"Deny",
            "Resource":"*"
        }
        ]
    }"""
    response = client.create_policy(
        PolicyName='DenyAccess',
        PolicyDocument=policy,
        Description='Disables student user Console access.'
    )

    iam = boto3.resource('iam')
    arnPolicy = 'arn:aws:iam::'+AccID+':policy/DenyAccess'

    response = client.attach_user_policy(
        UserName='student',
        PolicyArn=arnPolicy
    )

def handler_fun():
    pass_to_handler()

if __name__ == '__main__':
    handler_fun()
    